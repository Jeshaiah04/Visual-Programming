package Adapter

import Interface.Card
import Model.Hewan
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.kandangcrud.databinding.ActivityCardhewanBinding
import com.example.kandangcrud.R
import java.util.*



class HewanListAdapter (val listHewan: ArrayList<Hewan>, val cardListener: Card ):
    RecyclerView.Adapter<HewanListAdapter.viewHolder>(){
    class viewHolder (val itemView: View, val cardListener: Card): RecyclerView.ViewHolder(itemView) {

        val binding = ActivityCardhewanBinding.bind(itemView)
        fun setData(data: Hewan) {
            binding.HewanCardNama.text = data.nama
            binding.HewanCardJenis.text = data.jenis
            binding.HewanCardUsia.text = data.usia.toString()

            if (data.gambar.isNotEmpty()) {
                binding.HewanCardImage.setImageURI(Uri.parse(data.gambar))
            }
            itemView.setOnClickListener {
                cardListener.pencetKartu(adapterPosition)
            }
            binding.editButton.setOnClickListener {
                cardListener.pencetTombol("edit data",position)
            }

            binding.deleteButton.setOnClickListener {
                cardListener.pencetTombol("delete data",position)
            }
        }
    }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
            val layoutInflater = LayoutInflater.from(parent.context)
            val view = layoutInflater.inflate(R.layout.activity_cardhewan, parent, false)
            return viewHolder(view, cardListener)
        }

        override fun onBindViewHolder(holder: viewHolder, position: Int) {
            holder.setData(listHewan[position])
        }

        override fun getItemCount(): Int {
            return listHewan.size
        }

}