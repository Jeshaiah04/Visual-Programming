package Database

import Model.Hewan

class Data {
    companion object{
        val STORAGE_PERMISSION_CODE: Int = 50
        val listDataHewan = ArrayList<Hewan>()
    }
}