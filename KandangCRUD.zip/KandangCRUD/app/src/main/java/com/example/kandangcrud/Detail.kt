package com.example.kandangcrud

import Database.Data
import Model.Hewan
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_detail.*

class Detail : AppCompatActivity() {
    private var position = -1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        GetIntent()
        if (actionBar != null) {
            // Customize the back button
            actionBar!!.setHomeAsUpIndicator(R.drawable.backbutton);

            // showing the back button in action bar
            actionBar!!.setDisplayHomeAsUpEnabled(true);

        }

    }

    private fun GetIntent(){
        position = intent.getIntExtra("position", -1)
        val hewan = Data.listDataHewan[position]

        Display(hewan)
    }
    override fun onResume() {
        super.onResume()
        val hewan = Data.listDataHewan[position]
        Display(hewan)
    }

    private fun Display(hewan: Hewan){
        NamaHewan.text = hewan.nama
        UsiaHewan.text = hewan.usia.toString().trim()
        Gender.text = hewan.gender
        JenisHewan.text = hewan.jenis
        Catatan.text = hewan.catatan
        if (hewan.gambar.isNotEmpty()) {

            HewanImageView.setImageURI(Uri.parse(hewan.gambar))

        }
    }
}