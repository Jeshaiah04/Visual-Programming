package com.example.kandangcrud

import Model.Hewan
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.android.synthetic.main.activity_input.*
import Database.Data
import androidx.appcompat.app.AppCompatActivity

class Input : AppCompatActivity() {
    private lateinit var hewan: Hewan
    private var gambars: String = ""
    private var position = -1

    private val GetResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == Activity.RESULT_OK) {   // APLIKASI GALLERY SUKSES MENDAPATKAN IMAGE
                val uri = it.data?.data                 // GET PATH TO IMAGE FROM GALLEY
                if (uri != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        baseContext.getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    }
                }
                HewanImage.setImageURI(uri)  // MENAMPILKAN DI IMAGE VIEW
                gambars = uri.toString()

            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input)

        GetIntent()
        if (actionBar != null) {
            // Customize the back button
            actionBar!!.setHomeAsUpIndicator(R.drawable.backbutton);

            // showing the back button in action bar
            actionBar!!.setDisplayHomeAsUpEnabled(true);

        }
//        var actionBar = getSupportActionBar()
//
//        if (actionBar != null) {
//            // Customize the back button
//            actionBar.setHomeAsUpIndicator(R.drawable.backbutton);
//            if (position == -1) {
//                actionBar.setTitle("Tambah Data Hewan")
//            } else {
//                actionBar.setTitle("Edit Data Hewan")
//            }
//            // showing the back button in action bar
//            actionBar.setDisplayHomeAsUpEnabled(true);
//
//        }



        inputedData()
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.drawable.backbutton -> {
                finish()
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

    private fun GetIntent() {
        position = intent.getIntExtra("position", -1)
        if (position != -1) {
            AddHewanData.text = "Simpan Perubahan"
            val hewan = Data.listDataHewan[position]
            gambars = Data.listDataHewan[position].gambar
            display(hewan)
        }
    }

    private fun display(hewan: Hewan) {
        NamaHewanInput.editText?.setText(hewan.nama)
        UsiaInput.editText?.setText(hewan.usia.toString())
        GenderInput.editText?.setText(hewan.gender)
        JenisHewanInput.editText?.setText(hewan.jenis)
        CatatanKhusus.editText?.setText(hewan.catatan)
        if (gambars != "")
            HewanImage.setImageURI(Uri.parse(gambars))
    }

    private fun inputedData() {

        HewanImage.setOnClickListener {
            val myIntent = Intent(Intent.ACTION_OPEN_DOCUMENT)
            myIntent.type = "image/*"
            GetResult.launch(myIntent)
        }

        AddHewanData.setOnClickListener() {
            var usia: Int
            val nama = NamaHewanInput.editText?.text.toString().trim()
            if (UsiaInput.editText?.text?.isEmpty() == true) {
                usia = 0
            } else {
                usia = Integer.parseInt(UsiaInput.editText?.text.toString().trim())
            }
            val gender = GenderInput.editText?.text.toString().trim()
            val jenis = JenisHewanInput.editText?.text.toString().trim()
            val catatan = CatatanKhusus.editText?.text.toString().trim()

            hewan = Hewan(nama, usia, gender, jenis, catatan)
            if (gambars != "")
                hewan.gambar = gambars

            var isCompleted: Boolean = true
            if (hewan.nama!!.isEmpty()) {
                NamaHewanInput.error = "Tolong isi Nama Hewan!"
                isCompleted = false
            } else {
                NamaHewanInput.error = ""
            }


            if (hewan.usia!! < 1 || hewan.usia!! > 1500) {
                UsiaInput.error = "Tolong isi Usia Hewan!"
                isCompleted = false
            } else {
                UsiaInput.error = ""
            }


            if (hewan.gender!!.isEmpty()) {
                GenderInput.error = "Tolong isi Gender Hewan!"
                isCompleted = false
            } else {
                GenderInput.error = ""
            }

            if (hewan.jenis!!.isEmpty()) {
                JenisHewanInput.error = "Tolong isi Jenis Hewan!"
                isCompleted = false
            } else {
                JenisHewanInput.error = ""
            }

            if (hewan.catatan!!.isEmpty()) {
                CatatanKhusus.error = "Tolong isi Catatan Khusus untuk Hewan!"
                isCompleted = false
            } else {
                CatatanKhusus.error = ""
            }
            if (isCompleted) {
                if (position == -1) {
                    Data.listDataHewan.add(hewan)
                } else {
                    Data.listDataHewan[position] = hewan
                }
                finish()
            }
        }


    }
}