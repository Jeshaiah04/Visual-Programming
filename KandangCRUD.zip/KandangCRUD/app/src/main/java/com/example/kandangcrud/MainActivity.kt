package com.example.kandangcrud

import Adapter.HewanListAdapter
import Database.Data
import Interface.Card
import Model.Hewan
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cardhewan.*
import kotlinx.android.synthetic.main.activity_main.*
import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager

class MainActivity : AppCompatActivity(), Card {

    private val adapter = HewanListAdapter(Data.listDataHewan, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        CheckPermissions()
        setupRecyclerView()
        TambahhewanListener()


    }

    private fun setupRecyclerView(){
        val layoutManager = GridLayoutManager(baseContext,1)
        binatanglist.layoutManager = layoutManager
        binatanglist.adapter= adapter
        if (Data.listDataHewan.size>0){
            addhewantext.isVisible = false
        }
    }

    override fun onResume() {
        super.onResume()
        adapter.notifyDataSetChanged()
        addhewantext.isVisible = Data.listDataHewan.size <= 0



    }
    private fun TambahhewanListener(){
        tambahhewan.setOnClickListener(){
            val intent = Intent(this, Input::class.java).apply {
                putExtra("position", -1)
            }
            startActivity(intent)


        }

    }

    private fun CheckPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            // Requesting the permission
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), Data.STORAGE_PERMISSION_CODE)
        } else {
            Toast.makeText(this, "Storage Permission already granted", Toast.LENGTH_SHORT).show()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            // Requesting the permission
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), Data.STORAGE_PERMISSION_CODE)
        } else {
            Toast.makeText(this, "Storage Permission already granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun pencetKartu(position: Int) {
        val myIntent = Intent(this, Detail::class.java).apply {
            putExtra("position", position)
        }
        startActivity(myIntent)
    }

    override fun pencetTombol(event: String, position: Int) {
        if(event == "edit data"){
            val myIntent =Intent(this, Input::class.java).apply {
                putExtra("position", position)
            }
            startActivity(myIntent)
        }else{
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Hapus Data Hewan")
            builder.setMessage("Apakah kamu sangat yakin untuk menghapus data hewan?")


            builder.setPositiveButton(android.R.string.yes) { function, which ->
                Toast.makeText(this,"Data Hewan Berhasil Terhapus", Toast.LENGTH_SHORT).show()
                Data.listDataHewan.removeAt(position)

                adapter.notifyDataSetChanged()
            }

            builder.setNegativeButton(android.R.string.no) { dialog, which ->
                Toast.makeText(this,
                    android.R.string.no, Toast.LENGTH_SHORT).show()
            }
            builder.show()
    }

}









}