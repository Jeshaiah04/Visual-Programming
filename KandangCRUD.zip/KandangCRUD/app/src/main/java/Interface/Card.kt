package Interface

interface Card {
    fun pencetKartu(position: Int)

    fun pencetTombol(event: String, position: Int)
}